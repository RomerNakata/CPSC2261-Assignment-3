/*import {Bottle} from "./bottle.class";

describe("Placeholder Suite", function(){

    let b = 6;
    let bot = new Bottle(5);
    beforeEach(function() {

    });

    it("single bottle test", function() {
        const size = 5;
        bot.fill();
        expect(bot.getLiquidInside()).toBe(size);
    });

    it("empty bottle test", function() {
        bot.empty();
        expect(bot.getLiquidInside()).toBe(0);
    });

    it("pour test", function() {
        let bot1 = new Bottle(5);
        let bot2 = new Bottle(3);
        bot1.fill();
        bot1.pour(bot2);

        expect(bot1.getLiquidInside()).toBe(2);
        expect(bot2.getLiquidInside()).toBe(3);
    });

});*/